// Xiaohongshu 2026-11-25 Container Bridge (ES2017 + Chrome 61 safe)
function supportsFlexGap() {
  if (!document.body) return false;
  var flex = document.createElement("div");
  flex.style.position = "absolute";
  flex.style.visibility = "hidden";
  flex.style.display = "flex";
  flex.style.flexDirection = "column";
  flex.style.rowGap = "1px";
  flex.appendChild(document.createElement("div"));
  flex.appendChild(document.createElement("div"));
  document.body.appendChild(flex);
  var supported = flex.scrollHeight === 1;
  flex.parentNode.removeChild(flex);
  return supported;
}

function readBuildVersion(launchOptions) {
  var env = launchOptions && launchOptions.miniToolEnv;
  var val = env && env.buildVersion;
  if (typeof val !== "number" && typeof val !== "string") return null;
  if (!/^[1-9]\d{6,}$/.test(String(val))) return null;
  var ver = Number(val);
  return Number.isSafeInteger(ver) ? ver : null;
}

async function getBuildVersion() {
  var xhs = window.xhs;
  var syncVer = readBuildVersion(xhs && xhs.launchOptions);
  if (syncVer !== null) return syncVer;
  var mt = xhs && xhs.miniTool;
  if (!mt || typeof mt.getLaunchOptions !== "function") return null;
  try {
    var opts = await mt.getLaunchOptions();
    return readBuildVersion(opts);
  } catch (e) {
    return null;
  }
}

function getClientVersion(buildVersion) {
  return (Number.isSafeInteger(buildVersion) && buildVersion > 0)
    ? Math.floor(buildVersion / 1000)
    : null;
}

async function applyWindowAvoidance() {
  var mt = window.xhs && window.xhs.miniTool;
  var snap = window.xhs && window.xhs.launchOptions && window.xhs.launchOptions.miniToolEnv && window.xhs.launchOptions.miniToolEnv.windowInfo;
  function applyInfo(info) {
    if (!info || !info.safeArea) return;
    var mb = info.menuButtons || {};
    var cap = mb.capsule;
    function vis(r) { return r && r.width > 0 && r.height > 0; }
    var rects = vis(cap) ? [cap] : [mb.back, mb.me, mb.share].filter(vis);
    var top = info.safeArea.top || 0;
    for (var i = 0; i < rects.length; i++) {
      if (rects[i].bottom > top) top = rects[i].bottom;
    }
    document.documentElement.style.setProperty("--content-top", (top + 8) + "px");
  }
  if (snap) applyInfo(snap);
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  if (cv !== null && cv >= 9490 && mt && typeof mt.getWindowInfo === "function") {
    try {
      var liveInfo = await mt.getWindowInfo();
      applyInfo(liveInfo);
    } catch (e) {}
  }
}

async function xhsSaveData(key, obj) {
  var raw;
  try { raw = JSON.stringify(obj); } catch (e) { return false; }
  if (typeof raw !== "string") return false;
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv === null) return false;
  if (cv < 9460) {
    try { localStorage.setItem(key, raw); return true; } catch (e) { return false; }
  }
  if (!mt || typeof mt.setStorage !== "function") return false;
  try {
    var res = await mt.setStorage({ key: key, data: raw });
    return !!(res && res.errMsg === "setStorage:ok");
  } catch (e) {
    return false;
  }
}

async function xhsLoadData(key) {
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv === null) return null;
  if (cv < 9460) {
    try {
      var s = localStorage.getItem(key);
      return (!s) ? null : JSON.parse(s);
    } catch (e) { return null; }
  }
  if (!mt || typeof mt.getStorage !== "function") return null;
  try {
    var res = await mt.getStorage({ key: key });
    var d = res && res.data;
    if (d === null || d === "" || typeof d !== "string") return null;
    return JSON.parse(d);
  } catch (e) {
    return undefined;
  }
}

async function xhsTapHaptic() {
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv !== null && cv >= 9500 && mt && typeof mt.vibrateShort === "function") {
    try { await mt.vibrateShort({ type: "light" }); } catch (e) {}
  }
}

async function xhsCanvasToFileOrData(canvas) {
  var dataUrl = canvas.toDataURL("image/png");
  var mt = window.xhs && window.xhs.miniTool;
  if (mt && typeof mt.writeTempFile === "function") {
    try {
      var tmp = await mt.writeTempFile({ data: dataUrl });
      if (tmp && tmp.filePath) return tmp.filePath;
    } catch (e) {}
  }
  return dataUrl;
}

async function xhsSaveCanvasToAlbum(canvas, onToast) {
  var mt = window.xhs && window.xhs.miniTool;
  if (!mt || typeof mt.saveImageToPhotosAlbum !== "function") {
    onToast("请在小红书 App 内打开以一键保存高清图至相册");
    return;
  }
  try {
    var fp = await xhsCanvasToFileOrData(canvas);
    await mt.saveImageToPhotosAlbum({ filePath: fp });
    await xhsTapHaptic();
    onToast("已保存高清 3:4 海报到系统相册 ✨");
  } catch (e) {
    onToast("保存未完成：" + ((e && e.errMsg) ? e.errMsg : "请授权相册权限后重试"));
  }
}

async function xhsPostCanvasNote(canvas, title, content, onToast) {
  var mt = window.xhs && window.xhs.miniTool;
  if (!mt || typeof mt.postNote !== "function") {
    onToast("请在小红书 App 内点击即可一键带海报发笔记");
    return;
  }
  try {
    var fp = await xhsCanvasToFileOrData(canvas);
    await mt.postNote({
      title: title.slice(0, 20),
      content: content.slice(0, 900),
      pageType: "photo_publish",
      mediaInfo: { image_resources: [{ url: fp }] }
    });
  } catch (e) {
    onToast("拉起发布页未完成，可先点「存相册」再发笔记");
  }
}

async function xhsSetupShareBtn(btnEl, onToast) {
  if (!btnEl) return;
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv !== null && cv >= 9530 && mt && typeof mt.share === "function") {
    btnEl.style.display = "inline-flex";
    btnEl.addEventListener("click", async function () {
      try {
        await mt.share({ type: "card" });
      } catch (e) {
        onToast("当前半屏或模拟器暂不支持分享面板");
      }
    });
  } else {
    btnEl.style.display = "none";
  }
}

(function () {
  var RADARS = [
    { id: "cleanFood", zh: "🛡️ 科技与狠活" },
    { id: "sugarDiet", zh: "🔥 控糖减脂" },
    { id: "goutPurine", zh: "💧 痛风高尿酸" },
    { id: "momBaby", zh: "🤰 孕期宝妈" },
    { id: "acneSkincare", zh: "🧴 敏肌护肤" },
    { id: "petSafety", zh: "🐱 猫狗粮避雷" }
  ];

  var DB = [
    { id: "sd", zh: "脱氢乙酸钠", al: ["脱氢乙酸钠", "e265"], risk: "danger", p: 24, r: ["cleanFood", "momBaby"], reason: "新国标 GB 2760-2024 已禁用于面包糕点，建议避开。" },
    { id: "ho", zh: "氢化植物油/起酥油", al: ["氢化植物油", "起酥油", "人造奶油", "植脂末", "代可可脂"], risk: "danger", p: 26, r: ["cleanFood", "sugarDiet", "momBaby"], reason: "工业反式脂肪酸或廉价替代油脂核心来源。" },
    { id: "hfcs", zh: "果葡糖浆", al: ["果葡糖浆", "高果糖"], risk: "danger", p: 22, r: ["cleanFood", "sugarDiet", "goutPurine", "momBaby"], reason: "控糖与痛风高尿酸双重红灯，推高内脏脂肪与尿酸。" },
    { id: "yeast", zh: "酵母抽提物", al: ["酵母抽提物"], risk: "danger", p: 22, r: ["goutPurine"], reason: "痛风隐形高嘌呤来源，零添加酱油与浓汤常见。" },
    { id: "ig", zh: "呈味核苷酸二钠", al: ["呈味核苷酸二钠", "肌苷酸二钠", "e635"], risk: "danger", p: 24, r: ["goutPurine", "cleanFood"], reason: "直接代谢产生尿酸的增鲜剂，高尿酸期建议规避。" },
    { id: "tbhq", zh: "TBHQ 合成抗氧化剂", al: ["tbhq", "叔丁基对苯二酚"], risk: "danger", p: 20, r: ["cleanFood", "momBaby"], reason: "油炸零食常见合成油脂抗氧化剂。" },
    { id: "dye", zh: "人工合成色素", al: ["柠檬黄", "诱惑红", "日落黄", "亮蓝"], risk: "danger", p: 18, r: ["cleanFood", "momBaby"], reason: "纯染色无营养价值，儿童零食建议优选天然果蔬汁着色。" },
    { id: "suc", zh: "三氯蔗糖/安赛蜜/麦芽糊精", al: ["三氯蔗糖", "安赛蜜", "阿斯巴甜", "麦芽糊精"], risk: "caution", p: 12, r: ["cleanFood", "sugarDiet"], reason: "人工合成代糖或高升糖隐形碳水填料。" },
    { id: "ret", zh: "视黄醇(A醇) / MIT防腐", al: ["视黄醇", "甲基异噻唑啉酮", "dmdm", "羟苯丙酯"], risk: "danger", p: 24, r: ["acneSkincare", "momBaby"], reason: "孕期慎用成分或高致敏防腐剂，敏感肌易泛红。" },
    { id: "ipm", zh: "肉豆蔻酸异丙酯(高致痘)", al: ["肉豆蔻酸异丙酯", "棕榈酸异丙酯"], risk: "danger", p: 20, r: ["acneSkincare"], reason: "高致痘指数合成酯，油痘闭口肌建议避开。" },
    { id: "pet", zh: "BHA/BHT 或不明诱食肉粉", al: ["bha", "bht", "复合调味料", "诱食剂", "肉粉"], risk: "danger", p: 22, r: ["petSafety"], reason: "低端宠粮常见争议防腐剂或模糊肉源。" },
    { id: "clean", zh: "生牛乳 / 鲜肉 / 活性菌", al: ["生牛乳", "嗜热链球菌", "保加利亚乳杆菌", "鲜鸡肉", "鲜鸭肉", "三文鱼", "牛磺酸"], risk: "safe", p: 0, r: ["cleanFood", "petSafety"], reason: "干净透明的优质基础原料！" }
  ];

  var SAMPLES = [
    { id: "toast", zh: "网红手撕吐司(示例)", badge: "烘焙踩雷", text: "配料：小麦粉、白砂糖、人造奶油、氢化植物油、果葡糖浆、脱氢乙酸钠、三氯蔗糖、柠檬黄。" },
    { id: "yogurt", zh: "极简原味酸奶(示例)", badge: "干净模范", text: "配料：生牛乳（≥99%）、嗜热链球菌、保加利亚乳杆菌。" },
    { id: "ramen", zh: "浓汤海鲜泡面(示例)", badge: "痛风隐形雷", text: "配料：小麦粉、棕榈油、麦芽糊精、酵母抽提物、呈味核苷酸二钠、TBHQ。" },
    { id: "cat", zh: "平价无谷猫粮(示例)", badge: "谷物分割法", text: "原料组成：鸡肉粉、玉米、大米、小麦粉、豆粕、宠物饲料复合调味料、BHA、BHT。" }
  ];

  var activeMap = { cleanFood: true, sugarDiet: true, goutPurine: true, momBaby: true, acneSkincare: true, petSafety: true };
  var currentName = SAMPLES[0].zh;
  var lastResult = null;

  function showToast(msg) {
    var box = document.getElementById("toastBox");
    if (!box) return;
    box.textContent = msg;
    box.style.display = "block";
    setTimeout(function () { box.style.display = "none"; }, 3200);
  }

  function analyze(raw, name) {
    var clean = raw.replace(/^(配料表?|原料组成|成分表?)\s*[:：]/, "");
    var parts = clean.replace(/[（）()；;。]/g, "、").split(/[、,，/]/);
    var tokens = [];
    for (var i = 0; i < parts.length; i++) {
      var t = parts[i].trim();
      if (t) tokens.push(t);
    }
    var hits = [];
    var seen = {};
    for (var ti = 0; ti < tokens.length; ti++) {
      var low = tokens[ti].toLowerCase();
      for (var di = 0; di < DB.length; di++) {
        var entry = DB[di];
        if (seen[entry.id]) continue;
        var matched = false;
        for (var ai = 0; ai < entry.al.length; ai++) {
          if (low.indexOf(entry.al[ai]) !== -1) { matched = true; break; }
        }
        if (matched) {
          seen[entry.id] = true;
          var radarOn = false;
          for (var ri = 0; ri < entry.r.length; ri++) {
            if (activeMap[entry.r[ri]]) { radarOn = true; break; }
          }
          var effRisk = entry.risk === "safe" ? "safe" : (radarOn ? entry.risk : "caution");
          var effPen = entry.risk === "safe" ? 0 : (radarOn ? entry.p : Math.max(4, Math.round(entry.p / 3)));
          hits.push({ zh: entry.zh, reason: entry.reason, effRisk: effRisk, effPen: effPen });
        }
      }
    }

    var grains = ["玉米", "大米", "小麦", "豆粕"];
    var gCount = 0;
    var top6 = tokens.slice(0, 6);
    for (var gi = 0; gi < top6.length; gi++) {
      for (var gk = 0; gk < grains.length; gk++) {
        if (top6[gi].indexOf(grains[gk]) !== -1) { gCount++; break; }
      }
    }
    if (gCount >= 2 && activeMap.petSafety) {
      hits.unshift({ zh: "识破「谷物分割法」陷阱", reason: "前 6 位拆分塞入 " + gCount + " 种谷物/豆粕充数！", effRisk: "danger", effPen: 18 });
    }

    var pen = 0;
    var dangers = 0;
    for (var hi = 0; hi < hits.length; hi++) {
      pen += hits[hi].effPen;
      if (hits[hi].effRisk === "danger") dangers++;
    }
    var score = Math.max(8, Math.min(100, 100 - pen));
    var grade = score >= 85 ? "clean" : (score >= 65 ? "mild" : "danger");
    return { name: name, score: score, dangers: dangers, grade: grade, hits: hits };
  }

  function roundRect(ctx, x, y, w, h, r, fill) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function drawReportCanvas(res) {
    var cv = document.getElementById("reportCanvas");
    var ctx = cv.getContext("2d");
    ctx.fillStyle = "#F7F5EF";
    ctx.fillRect(0, 0, 900, 1200);

    roundRect(ctx, 50, 50, 800, 220, 30, "#151514");
    ctx.fillStyle = "#FF8080";
    ctx.font = "800 22px -apple-system, PingFang SC, sans-serif";
    ctx.fillText("PURESCAN · 配料照妖镜质检报告", 86, 104);
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "900 44px -apple-system, PingFang SC, sans-serif";
    ctx.fillText(String(res.name).slice(0, 12), 86, 168);

    var mainColor = res.grade === "clean" ? "#118A54" : (res.grade === "mild" ? "#D97706" : "#DA2525");
    ctx.fillStyle = mainColor;
    ctx.font = "800 28px -apple-system, PingFang SC, sans-serif";
    var verdict = res.grade === "clean" ? "✅ 配料干净 · 放心入" : (res.grade === "mild" ? "🟡 轻度添加 · 控量食用" : "⚠️ 红灯雷区 · 建议放回货架");
    ctx.fillText(verdict, 86, 224);

    ctx.textAlign = "right";
    ctx.fillStyle = mainColor;
    ctx.font = "900 84px -apple-system, sans-serif";
    ctx.fillText(String(res.score), 810, 182);
    ctx.fillStyle = "#9CA3AF";
    ctx.font = "700 20px -apple-system, sans-serif";
    ctx.fillText("CLEAN / 100", 810, 218);
    ctx.textAlign = "left";

    var y = 304;
    var shown = res.hits.slice(0, 5);
    if (shown.length === 0) {
      roundRect(ctx, 50, y, 800, 130, 24, "#E6F8EE");
      ctx.fillStyle = "#118A54";
      ctx.font = "800 32px -apple-system, PingFang SC, sans-serif";
      ctx.fillText("🟢 未检出高风险添加剂与忌口雷区！", 84, y + 76);
    } else {
      for (var i = 0; i < shown.length; i++) {
        var h = shown[i];
        var bg = h.effRisk === "danger" ? "#FDECEC" : (h.effRisk === "caution" ? "#FEF3DD" : "#E6F8EE");
        var fg = h.effRisk === "danger" ? "#DA2525" : (h.effRisk === "caution" ? "#B45309" : "#118A54");
        roundRect(ctx, 50, y, 800, 146, 22, bg);
        ctx.fillStyle = fg;
        ctx.font = "900 30px -apple-system, PingFang SC, sans-serif";
        var prefix = h.effRisk === "danger" ? "🔴 高危：" : (h.effRisk === "caution" ? "🟡 注意：" : "🟢 优质：");
        ctx.fillText(prefix + h.zh, 80, y + 56);
        ctx.fillStyle = "#262626";
        ctx.font = "600 23px -apple-system, PingFang SC, sans-serif";
        ctx.fillText(String(h.reason).slice(0, 30), 80, y + 106);
        y += 164;
      }
    }

    ctx.fillStyle = "#6B6961";
    ctx.font = "600 21px -apple-system, PingFang SC, sans-serif";
    ctx.fillText("配料照妖镜 PureScan · 依据 GB 2760 / INCI / AAFCO 公开标准科普解析", 50, 1152);
  }

  function runAnalyze() {
    var txt = document.getElementById("labelInput").value.trim();
    if (!txt) return;
    var res = analyze(txt, currentName);
    lastResult = res;
    var col = res.grade === "clean" ? "#118A54" : (res.grade === "mild" ? "#D97706" : "#DA2525");
    document.getElementById("resTitle").textContent = res.name;
    var sc = document.getElementById("resScore");
    sc.textContent = String(res.score);
    sc.style.color = col;
    var st = document.getElementById("resStamp");
    st.style.color = col;
    st.textContent = res.grade === "clean" ? "✅ 干净配料 · 闭眼入" : (res.grade === "mild" ? "🟡 轻度科技 · 偶尔解馋" : "⚠️ 检出 " + res.dangers + " 项红灯雷区");

    var hitsEl = document.getElementById("resHits");
    hitsEl.innerHTML = "";
    if (res.hits.length === 0) {
      var ok = document.createElement("div");
      ok.className = "hit-item safe";
      ok.innerHTML = "<div class='hit-top'>🟢 配料表干净清爽！</div>";
      hitsEl.appendChild(ok);
    } else {
      for (var i = 0; i < res.hits.length; i++) {
        var h = res.hits[i];
        var div = document.createElement("div");
        div.className = "hit-item " + h.effRisk;
        var dot = h.effRisk === "danger" ? "🔴 " : (h.effRisk === "caution" ? "🟡 " : "🟢 ");
        div.innerHTML = "<div class='hit-top'><span>" + dot + h.zh + "</span></div><div class='hit-reason'>" + h.reason + "</div>";
        hitsEl.appendChild(div);
      }
    }
    drawReportCanvas(res);
  }

  function renderRadars() {
    var wrap = document.getElementById("radarWrap");
    wrap.innerHTML = "";
    for (var i = 0; i < RADARS.length; i++) {
      (function (r) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "radar-chip" + (activeMap[r.id] ? " active" : "");
        btn.textContent = r.zh;
        btn.addEventListener("click", function () {
          activeMap[r.id] = !activeMap[r.id];
          var anyOn = false;
          for (var k in activeMap) { if (activeMap[k]) anyOn = true; }
          if (!anyOn) activeMap[r.id] = true;
          renderRadars();
          runAnalyze();
        });
        wrap.appendChild(btn);
      })(RADARS[i]);
    }
  }

  function renderSamples() {
    var grid = document.getElementById("sampleGrid");
    grid.innerHTML = "";
    for (var i = 0; i < SAMPLES.length; i++) {
      (function (s) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "sample-btn";
        btn.innerHTML = "<small>" + s.badge + "</small><strong>" + s.zh + "</strong>";
        btn.addEventListener("click", function () {
          currentName = s.zh.replace("(示例)", "");
          document.getElementById("labelInput").value = s.text;
          xhsTapHaptic();
          runAnalyze();
        });
        grid.appendChild(btn);
      })(SAMPLES[i]);
    }
  }

  function init() {
    if (supportsFlexGap()) {
      document.documentElement.classList.add("supports-flex-gap");
    }
    applyWindowAvoidance();
    renderRadars();
    renderSamples();
    document.getElementById("labelInput").value = SAMPLES[0].text;
    currentName = SAMPLES[0].zh.replace("(示例)", "");

    document.getElementById("scanBtn").addEventListener("click", function () {
      currentName = "自定义配料实测";
      xhsTapHaptic();
      runAnalyze();
    });

    document.getElementById("saveAlbumBtn").addEventListener("click", function () {
      var cv = document.getElementById("reportCanvas");
      xhsSaveCanvasToAlbum(cv, showToast);
    });

    document.getElementById("postNoteBtn").addEventListener("click", function () {
      var cv = document.getElementById("reportCanvas");
      var score = lastResult ? lastResult.score : 60;
      var title = "配料表实测：" + currentName + "得" + score + "分";
      var content = "买前用「配料照妖镜」扫了一下配料表，红黑榜一眼看穿！逛超市控糖、痛风、看猫粮再也不踩坑 🔍 #配料表 #食品添加剂 #超市避雷 #科技与狠活";
      xhsPostCanvasNote(cv, title, content, showToast);
    });

    xhsSetupShareBtn(document.getElementById("shareCardBtn"), showToast);
    runAnalyze();
  }

  init();
})();
